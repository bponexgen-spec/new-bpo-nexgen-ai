require('dotenv').config();
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');
const fetch = require('node-fetch');

const app = express();
app.use(require('cors')());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '..', 'client', 'dist')));

const bookingsPath = path.join(__dirname, 'data', 'bookings.json');
fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
if (!fs.existsSync(bookingsPath)) fs.writeFileSync(bookingsPath, JSON.stringify([]));

app.post('/api/book', (req, res) => {
  const { name, email, datetime } = req.body;
  if(!name || !email || !datetime) return res.status(400).json({ ok:false, message:'Missing fields' });
  const bookings = JSON.parse(fs.readFileSync(bookingsPath));
  bookings.push({ name, email, datetime, createdAt: new Date().toISOString() });
  fs.writeFileSync(bookingsPath, JSON.stringify(bookings, null, 2));
  return res.json({ ok:true, message:'Booking saved (demo)' });
});

app.post('/api/call/outbound', (req, res) => {
  return res.json({ ok:true, message:'Outbound call simulated (demo)' });
});
app.post('/api/call/inbound', (req, res) => {
  return res.json({ ok:true, message:'Inbound call simulated (demo)' });
});

app.post('/api/voice', async (req, res) => {
  try {
    const text = req.body.text || 'Hello from NexGen BPO AI demo.';
    const apiKey = process.env.ELEVENLABS_API_KEY;
    if(!apiKey) return res.status(500).json({ ok:false, message:'Missing ElevenLabs key in server environment.' });
    const url = 'https://api.elevenlabs.io/v1/text-to-speech/default';
    const resp = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'xi-api-key': apiKey
      },
      body: JSON.stringify({ text })
    });
    const arrayBuffer = await resp.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    res.set('Content-Type', 'audio/mpeg');
    res.send(buffer);
  } catch(err) {
    console.error('Voice API error', err);
    res.status(500).json({ ok:false, message:'Voice API failed (demo).', error: String(err) });
  }
});

app.get('/api/health', (req, res) => res.json({ ok:true, time: new Date().toISOString() }));

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'client', 'dist', 'index.html'));
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log('Server listening on', port));
