import React, {useState} from 'react'

export default function App(){
  const [lang, setLang] = useState(navigator.language.startsWith('nl') ? 'nl' : 'en');
  const [booking, setBooking] = useState({name:'',email:'',datetime:''});
  const [msg, setMsg] = useState('');
  const t = {
    en:{title:'NexGen BPO AI agency', demo:'Voice demo', book:'Book Appointment', watch:'Watch Reel'},
    nl:{title:'NexGen BPO AI agency', demo:'Stem demo', book:'Maak afspraak', watch:'Bekijk Reel'}
  };

  function openVideo(id){
    const url = `https://www.youtube.com/watch?v=${id}`;
    const win = window.open(url, '_blank');
    if(!win) alert('Popup blocked — allow popups to watch the reel.');
  }

  async function playVoice(){
    try{
      const res = await fetch('/api/voice', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ text: 'Hello from NexGen B P O AI demo' })});
      if(!res.ok) { alert('Voice demo failed'); return; }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audio.play();
    }catch(err){
      alert('Voice demo error');
    }
  }

  function simulateCall(type){
    alert(type + ' call simulated (demo).');
  }

  async function submitBooking(e){
    e.preventDefault();
    const res = await fetch('/api/book', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(booking)});
    const data = await res.json();
    setMsg(data.message || 'Saved');
    setBooking({name:'',email:'',datetime:''});
  }

  return (
    <div className='container'>
      <header className='header'>
        <h1>{t[lang].title}</h1>
        <div>
          <button className='button' onClick={()=>setLang('en')}>EN</button>
          <button className='button' style={{marginLeft:8}} onClick={()=>setLang('nl')}>NL</button>
        </div>
      </header>

      <section className='hero' style={{marginTop:12}}>
        <h2>Investor-ready demo</h2>
        <p>Professional pitch site with voice, call simulations, pricing and booking demo.</p>
        <div style={{marginTop:12}}>
          <img className='video-thumb' src='/assets/hero.jpg' alt='reel' onClick={()=>openVideo('40oRCiHA6EU')} />
          <div style={{marginTop:8}}>
            <button className='button' onClick={()=>openVideo('CwYwtF0crYQ')}>{t[lang].watch}</button>
          </div>
        </div>
      </section>

      <section style={{marginTop:12}}>
        <h3>Live Demos</h3>
        <div style={{display:'flex',gap:12}}>
          <div className='card' style={{flex:1}}>
            <h4>{t[lang].demo}</h4>
            <button className='button' onClick={playVoice}>Play Voice Demo</button>
          </div>
          <div className='card' style={{flex:1}}>
            <h4>Call Demo</h4>
            <button className='button' onClick={()=>simulateCall('Outbound')}>Outbound</button>
            <button className='button' style={{marginLeft:8}} onClick={()=>simulateCall('Inbound')}>Inbound</button>
          </div>
        </div>
      </section>

      <section style={{marginTop:12}} className='card'>
        <h3>Pricing Plans</h3>
        <div style={{display:'flex',gap:12}}>
          <div className='card' style={{flex:1}}><h4>Starter</h4><p>€49 / month</p></div>
          <div className='card' style={{flex:1}}><h4>Pro</h4><p>€199 / month</p></div>
          <div className='card' style={{flex:1}}><h4>Enterprise</h4><p>Contact us</p></div>
        </div>
      </section>

      <section style={{marginTop:12}} className='card'>
        <h3>{t[lang].book}</h3>
        <form onSubmit={submitBooking} style={{display:'grid',gap:8,maxWidth:420}}>
          <input placeholder='Name' value={booking.name} onChange={e=>setBooking({...booking,name:e.target.value})} required />
          <input placeholder='Email' value={booking.email} onChange={e=>setBooking({...booking,email:e.target.value})} required />
          <input placeholder='YYYY-MM-DD HH:MM' value={booking.datetime} onChange={e=>setBooking({...booking,datetime:e.target.value})} required />
          <button className='button' type='submit'>Send</button>
        </form>
        <p>{msg}</p>
      </section>

      <footer style={{marginTop:20, textAlign:'center', color:'#666'}}>
        <small>Terms · Privacy · EU Cookie (demo)</small>
      </footer>
    </div>
  )
}
